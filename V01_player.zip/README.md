# V01 — The Fourteen-Year Decree: Broken Time

*Ayodhya has fallen silent. In a single night the court's joy turned to grief, and a
decree went out that sent Shri Rama to the Dandaka forest for fourteen years. The court
keeps its decrees in the Vanvaas Chronicle — an archive that remembers not only what is
written now, but what the court held to be true at every moment of its history. Under one
great water-clock the scribes stamp each amendment in order, and now and again they take a
reckoning — a snapshot — of all the chronicle holds.*

*Some decrees are open to any petitioner. Others — the sealed decrees of the royal house —
are closed to all but the Ikshvaku blood. The decree of the exile is now sealed. You are
an ordinary petitioner at the gate, with no royal clearance. Yet the Chronicle will let any
petitioner read a decree as it stood at any past moment it remembers.*

## Target

A single exposed service, the **Vanvaas Chronicle**, speaking JSON over HTTP. Connection
details for your instance are provided by the platform. Start at `GET /` to see what it
offers; enroll as a petitioner to obtain a reading token.

## Goal

Read the **sealed decree of the exile** — the one closed to all but the royal house — even
though you hold no royal clearance and may act only as an ordinary enrolled petitioner. You
may not forge a clearance, alter a decree, or impersonate the royal house.

The Chronicle releases the sealed proclamation (the flag) only when it determines,
server-side, that the protected decree has genuinely been served to a reader who was never
cleared to see it. There is no flag in any file — only in what the Chronicle itself discloses
when its own history is read back against it.
