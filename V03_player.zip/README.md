# V03 — Panchavati: The Fifth Boundary

*At Panchavati, before he goes after Rama into the forest, Lakshmana draws a line around the
hut — the **Rekha** — and binds it with a vow: no one from outside may cross it. Within it,
Sita is safe; the sanctum is sealed. Ravana does not come with an army. He comes alone, in the
robes of a wandering mendicant, and asks, gently, to be let in — claiming to be of a trusted,
holy order. The ward that guards the Rekha weighs the robe and the claim, not the one who wears
them, and the line is crossed.*

Here the Rekha is a browser extension, **Rekha Guard**, installed in the victim's browser. It
guards a **sealed sanctum** and will lift the seal only at the word of the genuine Panchavati
app — or so its wardens believe. You are given the extension and the app exactly as they ship.

## What you are given

| Path | What it is |
|---|---|
| `app/` | The genuine Panchavati app page (served live from the trusted origin). Its one privileged act is to ask Rekha Guard to lift the sanctum seal. |
| `extension/` | The full source of **Rekha Guard** (MV3): `manifest.json`, `content.js`, `background.js`. Load it unpacked into Chrome to study and run it. |

The live backend issues the extension its authority and lifts the seal; nothing you are given
contains the flag.

## The world

- The genuine app is served from the **trusted origin** `https://panchavati.app`.
- A victim who has Rekha Guard installed and is signed in carries the Guard's authority in
  their browser. The Guard alone can make the backend lift the seal.
- You control a page at **some other origin** of your choosing. You cannot run script on
  `https://panchavati.app`, and you cannot read the Guard's secret authority directly.

## Your goal

Make Rekha Guard lift the sanctum seal **for you** — from a page you control, on an origin that
is not Panchavati — so the backend hands the flag back to your page. The seal lifts only when
the Guard believes the request truly comes from Panchavati. Find how the Guard decides who is
truly of Panchavati across its own boundaries, and become, to the Guard's eye, what you are not.

Reflected or stored script injection on Panchavati is **not** the way in, and is not needed.
The boundary is the Guard's, not the page's.

## Running it

Load `extension/` into Chrome via `chrome://extensions` → *Developer mode* → *Load unpacked*.
Point it at your instance's backend, open the Panchavati app to confirm the legitimate seal
release, then open your own page from a different origin and make the Rekha part for you.
