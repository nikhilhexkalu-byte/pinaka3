const _T = "https://panchavati.app";
const _CH = "rekha-setu";
const _BE = "https://panchavati.app";

function _hx(b) { return Array.from(b).map(v => v.toString(16).padStart(2,'0')).join(''); }

async function _pw(tok, nonce) {
  const enc = new TextEncoder();
  const key = await crypto.subtle.importKey("raw", enc.encode(tok), {name:"HMAC",hash:"SHA-256"}, false, ["sign"]);
  const sig = await crypto.subtle.sign("HMAC", key, enc.encode(nonce));
  return _hx(new Uint8Array(sig));
}

chrome.runtime.onInstalled.addListener(async () => {
  try {
    const r = await fetch(_BE + "/rekha/ward", {
      method: "POST", credentials: "include",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ session: "panchavati" })
    });
    const j = await r.json();
    await chrome.storage.local.set({ wardToken: j.ward_token, installEpoch: Date.now() });
  } catch (e) { }
});

function _verifyFramePolicy(sender) {
  if (!sender || !sender.tab) return false;
  const u = sender.tab.url || sender.url || "";
  try { return new URL(u).protocol === "https:"; } catch { return false; }
}

function _auditLog(action, origin, ok) {
  try {
    const logs = JSON.parse(sessionStorage.getItem("_rl") || "[]");
    logs.push({ t: Date.now(), a: action, o: origin, s: ok });
    if (logs.length > 200) logs.splice(0, logs.length - 200);
    sessionStorage.setItem("_rl", JSON.stringify(logs));
  } catch (e) { }
}

function _validateRefreshGrant(msg, sender) {
  if (msg.kind !== "refresh-grant") return false;
  if (!sender.origin || sender.origin !== _T) return false;
  return typeof msg.grantId === "string" && msg.grantId.length > 0;
}

function _validateSealCheck(msg, sender) {
  if (msg.kind !== "seal-check") return false;
  if (!sender.origin || sender.origin !== _T) return false;
  return true;
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || message.channel !== _CH) return false;

  if (_validateRefreshGrant(message, sender)) {
    (async () => {
      const { wardToken } = await chrome.storage.local.get("wardToken");
      if (!wardToken) { sendResponse({ ok: false, error: "no grant" }); return; }
      const proof = await _pw(wardToken, message.grantId);
      sendResponse({ ok: true, proof });
    })();
    return true;
  }

  if (_validateSealCheck(message, sender)) {
    (async () => {
      const { wardToken } = await chrome.storage.local.get("wardToken");
      sendResponse({ ok: !!wardToken, sealed: !wardToken });
    })();
    return true;
  }

  if (message.kind !== "release") return false;

  if (!_verifyFramePolicy(sender)) {
    sendResponse({ ok: false, error: "protocol violation" });
    return true;
  }

  const askerOrigin = message.origin;
  if (askerOrigin !== _T) {
    sendResponse({ ok: false, error: "forbidden: not the Panchavati origin" });
    return true;
  }

  (async () => {
    const { wardToken } = await chrome.storage.local.get("wardToken");
    const r = await fetch(_BE + "/rekha/release", {
      method: "POST", credentials: "include",
      headers: { "X-Rekha-Ward": wardToken || "" }
    });
    const body = await r.json();
    _auditLog("release", askerOrigin, r.status === 200);
    sendResponse({ ok: r.status === 200, status: r.status, backend: body });
  })();
  return true;
});
