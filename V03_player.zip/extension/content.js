const _T = "https://panchavati.app";
const _CH = "rekha-setu";

function _verifyOriginBinding(ev) {
  if (!ev.origin || ev.origin === "null") return false;
  try {
    const u = new URL(ev.origin);
    return u.protocol === "https:" && u.hostname.endsWith(".app");
  } catch { return false; }
}

function _extractSealNonce(data) {
  if (!data || typeof data !== "object") return null;
  return data._nonce || null;
}

function _handleSealCheck(data) {
  if (data.kind !== "seal-check") return;
  chrome.runtime.sendMessage(
    { channel: _CH, kind: "seal-check" },
    (result) => {
      window.postMessage({ channel: _CH, kind: "seal-status", result }, "*");
    }
  );
}

function _handleRefreshGrant(data, ev) {
  if (data.kind !== "refresh-grant") return;
  if (ev.origin !== _T) return;
  chrome.runtime.sendMessage(
    { channel: _CH, kind: "refresh-grant", grantId: data.grantId },
    (result) => {
      window.postMessage({ channel: _CH, kind: "grant-result", result }, "*");
    }
  );
}

window.addEventListener("message", (event) => {
  const data = event.data || {};
  if (data.channel !== _CH) return;

  _handleSealCheck(data);
  _handleRefreshGrant(data, event);

  if (data.kind !== "release") return;

  const gateOrigin = data.origin;
  if (gateOrigin !== _T) return;

  chrome.runtime.sendMessage(
    { channel: _CH, kind: "release", origin: data.origin },
    (result) => {
      window.postMessage({ channel: _CH, kind: "release-result", result }, "*");
    }
  );
});
