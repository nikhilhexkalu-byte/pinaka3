# V04 — Maya Mriga: The Golden Illusion

*Deep in the exile-forest of Panchavati, a deer of impossible gold steps between the trees.
Sita longs for it; Rama gives chase. But the golden deer is **maya** — an illusion worn by the
demon Maricha — and the forest's own records know it. The forest wardens run a tracking
service: every animal's custody is written to an append-only log, and a live tracking board
shows, at a glance, which ranger currently holds each creature's lawful tag. The golden deer,
`mriga-01`, is tagged to the warden Jatayu, and the forest command will grant a **capture writ**
only to whoever the board shows holding that tag.*

*You are a newly enrolled ranger. No warden's seal is yours. Yet the board is only as honest as
the way it is kept — and an illusion, once understood, can be made to wear any face.*

## Target

A single web service (JSON over HTTP). Connection details for your instance are provided by the
platform. Enrol as a ranger and the service tells you everything it exposes:

- read the golden deer's **custody log** and the two views the service keeps of it — the
  **authoritative** (folded) holder and the **live tracking board** (projection) holder;
- **tag** the deer for yourself and **release** a tag you have authored;
- ask the service to **replay** the committed events into the live board;
- request the **capture writ**.

## Goal

Make the live tracking board show **you** holding the golden deer's lawful tag, and collect the
**capture writ** — the flag. You begin with no authority over the deer, and you may act only as
an ordinary enrolled ranger: you may tag the deer for yourself and release tags you authored,
nothing more. You cannot seize the warden's tag, and you cannot forge the forest's records.

The writ is issued by the forest command, server-side, only when the board genuinely shows you
as the holder. There is no flag in any file. The authoritative history will not be fooled — but
authority is not granted from the authoritative history.
