# V02 — Chitrakuta: The Vanishing Footprints

*The exile deepens. Rama, Sita and Lakshmana have left the Ganga behind and vanished into the
forest of Chitrakuta, and the search party that follows can find no trail. All that survives of
their passage is a scattering of forgotten records: a cracked old **plate** of the region drawn
in a crooked bird's-eye perspective, a ring of ruined **watch-towers** whose sighting
instruments were never calibrated and whose logs are half-rotted, and a torn **trail record**
of which footprint followed which. No single record is enough. Yet the sages insist the party's
true path still lies hidden in the wreckage — one route of footprints on the true ground, if
only the records can be read back together.*

## What you are given

Three binary artifacts recovered from the Chitrakuta survey (all custom, undocumented formats —
no schema is published):

| File | What it is |
|---|---|
| `survey.gcp`  | **Surveyed control points.** For each known landmark: its **true ground** coordinate (from a modern survey) **and** its position as drawn on the old plate. Intact. |
| `towers.obs`  | **The watch-tower sightings.** Each tower recorded a single bearing reading (a "pixel" on its own scale) for the landmarks and for the fugitive-party sightings it could see. The instruments are **uncalibrated** — each tower's scale, zero-offset, emplacement and alignment are unknown and differ. Some records are **torn** (their checksum no longer matches) and must be discarded. |
| `route.frags` | **The partial trail record.** Directed "this footprint was followed by that one" successions, plus the trail-head. They reference tower-sighting ids. Sightings that no succession ever names are spurious (startled deer, decoys) and are **not** on the route. |

Nothing in these files is random filler — the whole corpus is one internally consistent survey
of one forest. The flag is **not** present in any file.

## Your goal

Recover the **route of true-ground footprints** — the single path the party truly walked
through Chitrakuta — that the records, read correctly together, uniquely determine. To get
there you must, in order:

1. **Invert the plate.** The old plate is a non-standard perspective rendering of the true
   ground; recover that projection from the control points and invert it.
2. **Self-calibrate the towers.** With no calibration data given, recover each tower's
   instrument scale and zero-offset (its intrinsics) and its emplacement and alignment (its
   pose) from the landmarks it sighted — ignoring the torn records.
3. **Triangulate the sightings.** Each tower gives only a bearing to a sighting; cross the
   bearings from the towers that saw it to fix each sighting, then map it back through the
   inverted plate to its true-ground position.
4. **Reconstruct the route.** Order the footprints by the partial successions, discarding the
   decoy sightings.

Present the route and the key facts you recovered to the forest surveyor's seal (the validator)
for your instance. The seal checks your answer against the forest's true history server-side
and, only on an exact match, returns the flag. There is exactly one route that passes; guessing
will not find it.

## Submission

`POST /chitrakuta/footprints` with a JSON body:

```json
{
  "route": [sighting_id, ...],
  "footprints": { "<sighting_id>": [X_num, X_den, Y_num, Y_den], ... },
  "projection_digest": "<sha256 hex>",
  "calibration": {
    "<tower_id>": [f_num, f_den, c_num, c_den, cos_num, cos_den,
                   sin_num, sin_den, ox_num, ox_den, oy_num, oy_den], ...
  }
}
```

- **route** — the ordered list of sighting ids from the trail-head to the last footprint
  (decoys excluded).
- **footprints** — for every footprint on the route, its exact **true-ground** coordinate
  `(X, Y)`, each component a reduced fraction `[numerator, denominator]`.
- **projection_digest** — a fingerprint of the recovered plate projection `H` (a 3×3 map, true
  ground → plate, in homogeneous coordinates): scale-normalise `H` so its last entry `H[8]`
  equals `1`, then for each of the 9 entries in row-major order form the string
  `index:numerator/denominator` (entry as its exact reduced fraction), join the nine with `;`,
  and take the SHA-256 hex.
- **calibration** — for every tower, its recovered instrument and pose model, each value a
  reduced fraction `[numerator, denominator]`: focal `f`, principal point `c`, orientation
  `cos`/`sin`, and plate-space position `(ox, oy)`, where the tower maps a plate point
  `g = (X, Y)` to the bearing reading
  `u = f · ( (−sin·(X−ox) + cos·(Y−oy)) / (cos·(X−ox) + sin·(Y−oy)) ) + c`.

All fields must be exactly right together. A route that looks plausible but rests on
uncalibrated readings, on the un-inverted plate, or on records the forest never truly kept will
be refused.
