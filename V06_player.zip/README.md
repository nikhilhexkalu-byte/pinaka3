# V06 — Jatayu: Echoes of the Fallen

*In the Vanvaas, the great eagle Jatayu threw himself against Ravana's chariot to save Sita,
and fell. Before he died he gave Rama his account of what he had seen. This recorder is the
rest of it — the telemetry Jatayu's instruments logged as he fought and fell. The wreck of the
recorder survives in three damaged channels, each a different kind of ruin. Reassemble the
final transmission the recorder meant to send, and the fallen eagle's last witness can be
heard.*

## What you are given

Three artifacts salvaged from the recorder (all custom, undocumented formats — no schema is
published):

| File | What it is |
|---|---|
| `recorder.fw` | A flat dump of the telemetry coprocessor's firmware. It is not executable; it must be read statically. It holds the parameters the rest of the recorder was configured with. |
| `radio.iq`    | An int8 I/Q capture of the recorder's radio downlink — the live transmission, burst by burst, through a noisy channel. Some bursts arrived damaged. |
| `flash.img`   | A dump of the recorder's on-board NAND flash, where the same telemetry was also journalled. The flash has been rewritten, garbage-collected, and left mid-write in places. |

Nothing in these files is random filler. The whole corpus is one internally consistent
recording of one flight. The flag is **not** present in any file.

## Your goal

Recover the recorder's **authentic final transmission** — the full ordered sequence of
telemetry chunks it meant to send. No single channel gives it to you: the radio lost some
chunks on the air, the flash holds them but not in transmit order, and only the firmware tells
you how to read either one or how their clocks relate. You must reconcile all three — read the
firmware, demodulate and error-correct the radio, rebuild what the flash truly holds, and line
up their independent timebases — until one, and only one, consistent transmission remains.

Present what you recovered to the recorder's seal (the validator) for your instance. It checks
your answer against the recorder's true history server-side and, only on an exact match,
returns the flag. There is exactly one transmission that passes; guessing will not find it.

## Submission

`POST /jatayu/transmission` with a JSON body:

```json
{
  "transmission_digest": "<sha256 hex>",
  "transmission_len": <integer>,
  "ftl_digest": "<sha256 hex>",
  "calibration": [Af_num, Af_den, Bf_num, Bf_den],
  "cadence": [w0, dw],
  "lost_slots": [slot, ...]
}
```

- **transmission_digest** — a fingerprint of the full recovered transmission: for each chunk
  in transmit order, its 2-byte little-endian slot index followed by its payload bytes, all
  concatenated and hashed with SHA-256 (hex).
- **transmission_len** — the number of chunks in the transmission.
- **ftl_digest** — a fingerprint of the flash state you rebuilt: for each live logical page,
  the string `lpn:version:flash_tick:payload_hex`, sorted ascending by logical page number,
  joined with `;`, hashed with SHA-256 (hex).
- **calibration** — the affine map from the recorder's wall clock to the flash controller's
  clock that you recovered, `flash_tick = (Af_num/Af_den) * wall + (Bf_num/Bf_den)`, each part
  a reduced fraction.
- **cadence** — the transmit-clock schedule you read from the firmware: `[w0, dw]`, where the
  wall time of transmit slot `i` is `w0 + i * dw`.
- **lost_slots** — the sorted transmit-slot indices whose chunks were lost on the air and had
  to be recovered from flash.

All fields must be exactly right together. A transmission that looks plausible but rests on a
flash state the recorder never truly committed, or on uncorrected radio, or on an uncalibrated
clock, will be refused.
